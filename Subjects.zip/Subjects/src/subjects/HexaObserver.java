public class HexaObserver extends Observer{

   public HexaObserver(Subjects subject){
      this.subject = subject;
      this.subject.attach(this);
 
   }

   @Override
   public void update() {
      System.out.println( "Hex String: " + Integer.toHexString( subject.getState() ).toUpperCase() ); 
   }
}