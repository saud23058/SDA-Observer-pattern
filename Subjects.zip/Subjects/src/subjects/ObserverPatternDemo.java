public class ObserverPatternDemo {
   public static void main(String[] args) {
      Subjects subject = new Subjects();

      HexaObserver hex=  new HexaObserver(subject);
      OctalObserver a= new OctalObserver(subject);
      new BinaryObserver(subject);
      subject.dettach(hex);
      a.isActive=false;
      System.out.println("First state change: 15");	
      subject.setState(15);
      System.out.println("Second state change: 10");	
      subject.setState(10);
   }
    }