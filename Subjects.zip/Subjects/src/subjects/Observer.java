public abstract class Observer {
   protected Subjects subject;
   boolean isActive = true;
   public abstract void update();
}